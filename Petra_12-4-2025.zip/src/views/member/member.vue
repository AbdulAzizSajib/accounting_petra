<template>
  <MemberLayout>
    <h1>Payroll Home</h1>
  </MemberLayout>
</template>
<script setup>
import MemberLayout from "@/components/layouts/MemberLayout.vue";

</script>